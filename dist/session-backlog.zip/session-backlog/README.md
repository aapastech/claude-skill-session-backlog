# session-backlog

A Claude skill that stops Claude forgetting tasks in long or parallel sessions.

Every task and sub-task you give Claude is written to a backlog **on your own computer**, with an area, an ETA, and the session that created and finished it. Claude re-reads the backlog every turn and ends each reply with what's still open. A board in your browser shows everything at a glance.

- Task data never leaves your computer. There's no cloud storage and no account to create.
- Every Claude session on your computer shares the same backlog, and so does any session linked to that computer (desktop, Claude Code, cloud, phone).
- The engine is a single Python 3 file using only the standard library. Nothing needs installing; macOS and Linux include Python 3.

## Install

**Claude app (web, desktop, mobile):** download `session-backlog.zip`, then go to **Customize → Skills → + → Create skill → Upload a skill** and pick the ZIP. Make sure the skill is switched on.

**Claude Code:** unzip into `~/.claude/skills/` so you have `~/.claude/skills/session-backlog/SKILL.md`.

**Make it always-on (recommended):** add this line to your Claude personal preferences (Settings → Profile), or to `~/.claude/CLAUDE.md` for Claude Code:

> Always load the session-backlog skill at the start of every session and before any task with work in it.

## First use

Start a chat and give Claude a few tasks. On first use Claude will:
1. create `~/Documents/Claude-Backlog` on your computer (asking for folder access if needed)
2. ask your name and the areas your work falls into
3. capture your tasks and show you where the board is (`board.html` in that folder)

## Requirements

- Claude needs a way to reach your computer: Claude Code, or the Claude desktop app with a linked computer.
- When your computer isn't reachable (for example, a phone chat that isn't linked), Claude queues updates and syncs them when it's back.
